/*
 * @author Sariah Schulteis
 * A class that gets the file, stores data into the array, and run the inquiry
 */
package assg4_schulteiss20;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class StudentSearch {

	public static void main(String[] args) {
		Student[] students = new Student[100];
		Scanner keyboard = new Scanner(System.in);
		String filename = "assg4_roster.txt";
		Scanner inputStream = null;
		String line;

		try { // reads input from file
			inputStream = new Scanner(new File(filename));
		} catch (FileNotFoundException e) {
			System.out.println("Error opening the file " + filename);
			System.exit(1);
		}
		int increment = 0;
		while (inputStream.hasNextLine()) {
			line = inputStream.nextLine();
			String[] array = line.split("\\s+");
			students[increment] = new Student(Integer.parseInt(array[0]), array[1], array[2], array[3].charAt(0),
					array[4], array[5]); // stores into array
			increment++;
		}
		inputStream.close();
		String input1;
		do { // gets first and last name from user
			System.out.print("Enter last name: ");
			String last_name = keyboard.nextLine();
			System.out.print("Enter first name: ");
			String first_name = keyboard.nextLine();

			try {
				int position = Student.StudentSearch(students, increment, last_name, first_name);
				System.out.println(students[position]);
			} catch (StudentNotFoundException e) {
				System.out.println(e.getMessage());
			}
			System.out.println();
			System.out.print("Do you want to search for another student (Y/N)? ");
			input1 = keyboard.nextLine();
			System.out.println();

		} while (!input1.equalsIgnoreCase("N"));

		keyboard.close();
	}

}
