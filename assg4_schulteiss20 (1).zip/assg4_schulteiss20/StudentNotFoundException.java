/*
 * @author Sariah Schulteis 
 * A class that defines the checked exception
 */
package assg4_schulteiss20;

@SuppressWarnings("serial")
public class StudentNotFoundException extends Exception {
	/*
	 * Default constructor
	 */
	public StudentNotFoundException() {
		super("No such student");
	}

	/*
	 * Constructor with parameter of String
	 * 
	 * @param String
	 */
	public StudentNotFoundException(String s) {
		super(s);
	}
}
