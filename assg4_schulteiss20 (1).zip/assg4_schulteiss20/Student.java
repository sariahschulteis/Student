/*
 * @author Sariah Schulteis
 * This class is for the Student that include id, last name, first name, gender, date of birth, and major.
 */

package assg4_schulteiss20;

/*
 * Initializes variables
 */

public class Student {
	private int id;
	private String last_name;
	private String first_name;
	private char gender;
	private String date_of_birth;
	private String major;

	/*
	 * @param id, last_name, first_name, gender, date_of_birth, major Constructor
	 * with id, last name, first name, gender, date of birth, and major
	 */
	public Student(int id, String last_name, String first_name, char gender, String date_of_birth, String major) {
		this.id = id;
		this.last_name = last_name;
		this.first_name = first_name;
		this.gender = gender;
		this.date_of_birth = date_of_birth;
		this.major = major;
	}

	/*
	 * Searches the array of students for student with given first and last name
	 * 
	 * @return index
	 */
	public static int StudentSearch(Student[] students, int StuNum, String last_name, String first_name)
			throws StudentNotFoundException {
		int i = 0;
		for (i = 0; i < StuNum; i++) {
			if (last_name.equalsIgnoreCase(students[i].getLastName())
					&& first_name.equalsIgnoreCase(students[i].getFirstName())) {
				return i;
			}

		}

		throw new StudentNotFoundException();
	}

	/*
	 * Retrieve the ID
	 * 
	 * @return id
	 */
	public int getID() {
		return id;
	}

	/*
	 * Retrieve last name
	 * 
	 * @return last_name
	 */
	public String getLastName() {
		return last_name;
	}

	/*
	 * Retrieve first name
	 * 
	 * @return first_name
	 */
	public String getFirstName() {
		return first_name;
	}

	/*
	 * Retrieve gender
	 * 
	 * @return gender
	 */
	public char getGender() {
		return gender;
	}

	/*
	 * Retrieve date of birth
	 * 
	 * @return date_of_birth
	 */
	public String getDateOfBirth() {
		return date_of_birth;
	}

	/*
	 * Retrieve major
	 * 
	 * @return major
	 */
	public String getMajor() {
		return major;
	}

	/*
	 * Return a string with id, last name, first name, gender, date of birth, and
	 * major
	 * 
	 * @return id, last name, first name, gender, date of birth, and major
	 */
	@Override
	public String toString() {
		return "Id: " + id + " Last name: " + last_name + " First name: " + first_name + " Gender: " + gender
				+ " Date of birth: " + date_of_birth + " Major: " + major;

	}

}
